﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GCAL.Base
{
    public class GPYoga
    {
        public static string getName(int i)
        {
            return GPStrings.getSharedStrings().getString(i + 660);
        }
    }
}
